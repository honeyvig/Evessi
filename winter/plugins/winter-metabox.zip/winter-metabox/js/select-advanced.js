/**
 * Update select2
 * Used for static & dynamic added elements (when clone)
 */
jQuery( document ).ready( function ( $ )
{	
	"use strict";
	$( ':input.wb-select-advanced' ).each( wb_update_select_advanced );
	$( '.wb-input' ).on( 'clone', ':input.wb-select-advanced', wb_update_select_advanced );
	
	function wb_update_select_advanced()
	{
		var $this = $( this ),
			options = $this.data( 'options' );
		$this.siblings('.select2-container').remove();
		$this.select2( options );	
	}
} );