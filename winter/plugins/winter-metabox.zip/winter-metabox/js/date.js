/**
 * Update date picker element
 * Used for static & dynamic added elements (when clone)
 */
jQuery( document ).ready( function( $ )
{
	"use strict";
	$( ':input.wb-date' ).each( wb_update_date_picker );
	$( '.wb-input' ).on( 'clone', ':input.wb-date', wb_update_date_picker );
	
	function wb_update_date_picker()
	{
		var $this = $( this ),
			options = $this.data( 'options' );
	
		$this.siblings( '.ui-datepicker-append' ).remove();         // Remove appended text
		$this.removeClass( 'hasDatepicker' ).attr( 'id', '' ).datepicker( options );
	}

} );
