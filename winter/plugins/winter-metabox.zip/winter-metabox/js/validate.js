jQuery( document ).ready( function( $ )
{
	"use strict"; 
	var $form = $( '#post' );

	// Required field styling
	$.each( wb.validationOptions.rules, function( k, v )
	{
		if ( v['required'] )
			$( '#' + k ).parent().siblings( '.wb-label' ).addClass( 'required' ).append( '<span>*</span>' );
	} );

	wb.validationOptions.invalidHandler = function( form, validator )
	{
		// Re-enable the submit ( publish/update ) button and hide the ajax indicator
		$( '#publish' ).removeClass( 'button-primary-disabled' );
		$( '#ajax-loading' ).attr( 'style', '' );
		$form.siblings( '#message' ).remove();
		$form.before( '<div id="message" class="error"><p>' + wb.summaryMessage + '</p></div>' );
	};

	$form.validate( wb.validationOptions );
} );