/**
 * Update datetime picker element
 * Used for static & dynamic added elements (when clone)
 */
jQuery( document ).ready( function( $ )
{
	"use strict";
	$( ':input.wb-time' ).each( wb_update_time_picker );
	$( '.wb-input' ).on( 'clone', ':input.wb-time', wb_update_time_picker );
	
	function wb_update_time_picker()
	{
		var $this = $( this ),
			options = $this.data( 'options' );
	
		$this.siblings( '.ui-datepicker-append' ).remove();         // Remove appended text
		$this.removeClass( 'hasDatepicker' ).attr( 'id', '' ).timepicker( options );
	
	}
} );
