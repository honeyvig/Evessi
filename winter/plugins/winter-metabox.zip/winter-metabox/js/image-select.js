jQuery( function( $ )
{
	"use strict"; 
	$( 'body' ).on( 'change', '.wb-image-select input', function()
	{
		var $this = $( this ),
			type = $this.attr( 'type' ),
			selected = $this.is( ':checked' ),
			$parent = $this.parent(),
			$others = $parent.siblings();
		if ( selected )
		{
			$parent.addClass( 'wb-active' );
			type == 'radio' && $others.removeClass( 'wb-active' );
		}
		else
		{
			$parent.removeClass( 'wb-active' );
		}
	} );
	$( '.wb-image-select input' ).trigger( 'change' );
} );