<?php
/*
Plugin Name: Pixeltemplate Meta Box
Plugin URI: http://www.pixeltemplate.com
Description: Pixeltemplate meta box for editing pages for Pixeltemplate wordpress themes.
Version: 1.0
Author: Pixeltemplate
Author URI: http://www.pixeltemplate.com
Text Domain: Winter-meta-box
*/

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

// Script version, used to add version for scripts and styles
define( 'WB_VER', '1.0.0' );

// Define plugin URLs, for fast enqueuing scripts and styles
if ( ! defined( 'WB_URL' ) )
	define( 'WB_URL', plugin_dir_url( __FILE__ ) );
define( 'WB_JS_URL', trailingslashit( WB_URL . 'js' ) );
define( 'WB_CSS_URL', trailingslashit( WB_URL . 'css' ) );

// Plugin paths, for including files
if ( ! defined( 'WB_DIR' ) )
	define( 'WB_DIR', plugin_dir_path( __FILE__ ) );
	define( 'WB_INC_DIR', trailingslashit( WB_DIR . 'inc' ) );
	define( 'WB_FIELDS_DIR', trailingslashit( WB_INC_DIR . 'fields' ) );

// Optimize code for loading plugin files ONLY on admin side
// @see http://www.deluxeblogtips.com/?p=345

// Helper function to retrieve meta value
require_once WB_INC_DIR . 'helpers.php';

if ( is_admin() )
{
	require_once WB_INC_DIR . 'common.php';
	require_once WB_INC_DIR . 'field.php';

	// Field classes
	foreach ( glob( WB_FIELDS_DIR . '*.php' ) as $file )
	{
		require_once $file;
	}

	// Main file
	require_once WB_INC_DIR . 'meta-box.php';
	require_once WB_INC_DIR . 'init.php';
}

// define global metaboxes array
global $wntr_META_BOXES;
$wntr_META_BOXES = array();
// include metaboxes
$metaboxes = array(
	'metaboxes-post.php',
	'metaboxes-common.php',
	'metaboxes-page.php',
	'metaboxes-testimonial.php',
	'metaboxes-staff.php'
);
foreach ( $metaboxes as $metabox ) {
	require_once WB_INC_DIR . $metabox ;		
}
/**
 * Register meta boxes
 *
 * @return void
 */
if( ! function_exists( 'rw_register_meta_box' ) ) {
add_action( 'admin_init', 'rw_register_meta_box' );
function rw_register_meta_box()
{
	// Make sure there's no errors when the plugin is deactivated or during upgrade
	if ( !class_exists( 'RW_Meta_Box' ) ) {
		return;
	}	
	global $wntr_META_BOXES;	
	foreach ( $wntr_META_BOXES as $meta_box ) {
		new RW_Meta_Box( $meta_box );
	}
}
}
/**
 * Localize meta boxes
 *
 * @return void
 */
if( ! function_exists( 'presscore_localize_meta_boxes' ) ) {
function presscore_localize_meta_boxes() {
	global $wntr_META_BOXES;
	$localized_meta_boxes = array();
	foreach ( $wntr_META_BOXES as $meta_box ) {
		$localized_meta_boxes[ $meta_box['id'] ] = isset($meta_box['display_on'], $meta_box['display_on']['template']) ? (array) $meta_box['display_on']['template'] : array(); 
	}
	wp_localize_script( 'wntr-metabox-script', 'wtMetaboxes', $localized_meta_boxes );
}
add_action( 'admin_enqueue_scripts', 'presscore_localize_meta_boxes', 15 );
}
/* End Metabox */