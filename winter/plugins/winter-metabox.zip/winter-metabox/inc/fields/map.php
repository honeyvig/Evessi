<?php
// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( !class_exists( 'WB_Map_Field' ) )
{
	class WB_Map_Field extends WB_Field
	{
		/**
		 * Enqueue scripts and styles
		 *
		 * @return void
		 */
		static function admin_enqueue_scripts()
		{
			wp_enqueue_script( 'googlemap', 'https://maps.google.com/maps/api/js?sensor=false', array(), '', true );
			wp_enqueue_script( 'wb-map', WB_JS_URL . 'map.js', array( 'jquery', 'jquery-ui-autocomplete', 'googlemap' ), WB_VER, true );
		}

		/**
		 * Get field HTML
		 *
		 * @param mixed  $meta
		 * @param array  $field
		 *
		 * @return string
		 */
		static function html( $meta, $field )
		{
			$address = isset( $field['address_field'] ) ? $field['address_field'] : false;

			$html = '<div class="wb-map-field">';

			$html .= sprintf(
				'<div class="wb-map-canvas" style="%s"%s></div>
				<input type="hidden" name="%s" class="wb-map-coordinate" value="%s">',
				isset( $field['style'] ) ? $field['style'] : '',
				isset( $field['std'] ) ? " data-default-loc=\"{$field['std']}\"" : '',
				$field['field_name'],
				$meta
			);

			if ( $address )
			{
				$html .= sprintf(
					'<button class="button wb-map-goto-address-button" value="%s">%s</button>',
					is_array( $address ) ? implode( ',', $address ) : $address,
					esc_html__( 'Find Address', 'harvest' )
				);
			}

			$html .= '</div>';

			return $html;
		}
	}
}
