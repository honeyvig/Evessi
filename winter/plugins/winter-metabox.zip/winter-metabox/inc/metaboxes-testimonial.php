<?php
/***********************************************************/
// Testimonial Template options
/***********************************************************/
$prefix = 'wntr_testimonial_list_';
$wntr_META_BOXES[] = array(
	'id'		=> 'wntr_testimonial_list_columns',
	'title' 	=> esc_html__('WT - List Options', 'Evessi'),
	'pages' 	=> array( 'page' ),
	'context' 	=> 'normal',
	'priority' 	=> 'high',
	'local_images' => true,
	'fields' 	=> array(	
		// Show number of posts per page
		array(
			'name'			=> esc_html__('Number of posts per page:', 'Evessi'),
			'id'    		=> "{$prefix}posts_per_page",
			'type'  		=> 'text',
			'std'   		=> '5',
		),
	),
	'display_on'	=> array( 'template' => array(
		'page-templates/testimonial-list.php',
	) ),
);
$prefix = 'wntr_testimonial_box_';
$wntr_META_BOXES[] = array(
	'id'		=> 'wntr_testimonial_box_columns',
	'title' 	=> esc_html__('WT - Box Options', 'Evessi'),
	'pages' 	=> array( 'page' ),
	'context' 	=> 'normal',
	'priority' 	=> 'high',
	'local_images' => true,
	'fields' 	=> array(	
		// Show posts per column
		array(
			'name'    		=> esc_html__('Columns Options:', 'Evessi'),
			'id'      		=> "{$prefix}columns",
			'type'    		=> 'radio',
			'std'			=> 'two',
			'options'		=> array(
				'two'		=> 'Two',
				'three'		=> 'Three',
				'four'		=> 'Four', 
			)
		),
		// Show number of posts per page
		array(
			'name'			=> esc_html__('Number of posts per page:', 'Evessi'),
			'id'    		=> "{$prefix}posts_per_page",
			'type'  		=> 'text',
			'std'   		=> '5',
		),
	),
	'display_on'	=> array( 'template' => array(
		'page-templates/testimonial-box.php'
	) ),
);
?>