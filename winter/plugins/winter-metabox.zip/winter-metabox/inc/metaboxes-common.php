<?php
/***********************************************************/
// Common options
/***********************************************************/
$prefix = 'wntr_content_';
$wntr_META_BOXES[] = array(
	'id'		=> 'wntr_content_area',
	'title' 	=> esc_html__('wt - Content Options:', 'Evessi'),
	'pages' 	=> array( 'page' ),	
	'context' 	=> 'side',
	'priority' 	=> 'low',
	'local_images' => true,
	'fields' 	=> array(	
		// Show sidebar position on post page
		array(
			'name'    		=> esc_html__('Content Position:', 'Evessi'),
			'id'      		=> "{$prefix}position",
			'type'    		=> 'radio',
			'std'			=> 'above',
			'options'		=> array(
				'none'		=> 'None',
				'above'		=> 'Above',
				'below'		=> 'Below',
			),
			'top_divider'	=> true
		),
	),
);
$prefix = 'wntr_page_';
$wntr_META_BOXES[] = array(
	'id'		=> 'wntr_page_width_layout',
	'title' 	=> esc_html__('wt - Page Layout:', 'Evessi'),
	'pages' 	=> array( 'page' ),	
	'context' 	=> 'side',
	'priority' 	=> 'low',
	'local_images' => true,
	'fields' 	=> array(	
		// Show sidebar position on post page
		array(
			'name'    		=> esc_html__('Page Layout:', 'Evessi'),
			'id'      		=> "{$prefix}layout",
			'type'    		=> 'radio',
			'std'			=> 'box',
			'options'		=> array(
				'box'		=> 'Box',
				'wide'		=> 'Wide',
			),
			'top_divider'	=> true
		),
	),
);
$prefix = 'wntr_sidebar_';
$wntr_META_BOXES[] = array(
	'id'		=> 'wntr_posts_other_side',
	'title' 	=> esc_html__('wt - Sidebar Options:', 'Evessi'),
	'pages' 	=> array( 'page' ),	
	'context' 	=> 'side',
	'priority' 	=> 'low',
	'local_images' => true,
	'fields' 	=> array(	
		// Show sidebar position on post page
		array(
			'name'    		=> esc_html__('Sidebar Position:', 'Evessi'),
			'id'      		=> "{$prefix}position",
			'type'    		=> 'radio',
			'std'			=> 'left',
			'options'		=> array(
				'right'		=> 'Right',
				'left'		=> 'Left',
				'disabled'	=> 'Disabled',
			),
			'top_divider'	=> true
		),
	),
);
?>