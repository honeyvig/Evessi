<?php
/*
Plugin Name: Pixeltemplate Shortcode
Plugin URI: http://www.pixeltemplate.com
Description: Pixeltemplate Custom Shortcodes for Pixeltemplate wordpress themes.
Version: 1.0
Author: Pixeltemplate
Author URI: http://www.pixeltemplate.com
*/
?>
<?php
if ( ! defined( 'WT_SHORTCODE_DIR' ) ) {
    define( 'WT_SHORTCODE_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'WT_SHORTCODE_URL' ) ) {
    define( 'WT_SHORTCODE_URL', plugin_dir_url( __FILE__ ) );
}

if(!class_exists('WT_shortcode'))
{
    class WT_shortcode{

        // Constructor
        function __construct() {
          
          
          add_action( 'admin_enqueue_scripts', array( $this,'wntr_shortcode_wp_admin_style'));
          add_action('setup_theme', array($this,'wt_addons_register_custom_post_type') );
          add_action( 'plugins_loaded', array( $this,'wntr_shortcode_install'), 11);
          if(class_exists('Vc_Manager')){
            add_action('init', array( $this,'wntr_shortcode_init'),40);
          }

        }
         
        function wntr_shortcode_init()
        {
         
          // Require new custom Element
          require_once( WT_SHORTCODE_DIR.'/vc-elements/vc-element.php' );
          require_once( WT_SHORTCODE_DIR.'/shortcodes/Winter-shortcodes.php' );
        }

        

        function wntr_shortcode_install() {
            if ( ! function_exists( 'is_plugin_active' ) ) {
                require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            }
        }
          
        function wntr_shortcode_wp_admin_style() {
            wp_register_style( 'wtshortcode-style', WT_SHORTCODE_URL.'assets/css/style.css', false, '1.0.0' );
            wp_enqueue_style( 'wtshortcode-style' );
        }
          
        function wntr_get_categories( $category ) {
            $categories = get_categories( array( 'taxonomy' => $category ));
            $array = array( '' => __( 'All', 'wntr-opts' ) );
            foreach( $categories as $cat ){
                if( is_object($cat) ) $array[$cat->slug] = $cat->name;
            }
            return $array;
        }

        function wt_addons_register_custom_post_type()
        {
          require_once( WT_SHORTCODE_DIR.'/custom-post/winter-custompost.php'); 
        }
          
    }

  $WT_shortcode = new WT_shortcode();
}
?>