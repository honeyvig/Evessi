<?php
/**
 * Visual Composer functions
 *
 * @author Pixeltemplate
 * @link http://pixeltemplate.com
 */
/* ---------------------------------------------------------------------------
 * Shortcodes | Image compatibility
 * --------------------------------------------------------------------------- */
if( ! function_exists( 'wntr_vc_image' ) )
{
	function wntr_vc_image( $image = false ){
		if( $image && is_numeric( $image ) ){
			$image = wp_get_attachment_image_src( $image, 'full' );
			$image = $image[0];
		}
		return $image;
	}
}

if( ! function_exists( 'wntr_get_categories' ) )
{
	function wntr_get_categories( $category ) {
	    $categories = get_categories( array( 'taxonomy' => $category ));
	    $array = array( '' => __( 'All', 'wntr-opts' ) );
	    foreach( $categories as $cat ){
	        if( is_object($cat) ) $array[$cat->slug] = $cat->name;
	    }
	    return $array;
	}
}

/* ---------------------------------------------------------------------------
 * Shortcodes | blog
 * --------------------------------------------------------------------------- */

// Accordition	
	vc_map( array (
			'name' 			=> __('Accordion', 'wntr-opts'),
			'description' 	=> __('Collapsible content panels', 'wntr-opts'),
			'base' 			=> 'wntr_accordion',
			"as_parent" => array('only' => 'accordion'),
    		"content_element" => true,
    		"show_settings_on_create" => true,
			 "js_view" => 'VcColumnView',
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-accordion',
			'params' 		=> array (
				array (
					'param_name' 	=> 'style',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Style', 'wntr-opts'),
					'description' 	=> __('Select type of accordion style.', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
						'3'		=> __('Three', 'wntr-opts'),
						'4'		=> __('Four', 'wntr-opts'),
					)),
				),
		)
	));	

 	vc_map( array (
			'base' 			=> 'accordion',
			'name' 			=> __('Accordation Content', 'wntr-opts'),
			"content_element" => true,
		    "as_child" => array('only' => 'wntr_accordion'),
			"show_settings_on_create" => true,	
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-accordion',
			'params' 		=> array (
				array (
					'param_name' 	=> 'title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'description' 	=> __('Title ex.Welcome To Store', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
		)
	));
// Blogs
	vc_map( array (
			'base' 			=> 'blog_posts',
			'name' 			=> __('Blogs', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-blog_slider',
			'description' 	=> __('Blogs in grid or slider', 'wntr-opts'),
			'params' 		=> array (
				array (
					'param_name' 	=> 'type',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Type', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'grid'		=> __('Grid', 'wntr-opts'),	
						'slider'	=> __('Slider', 'wntr-opts'),
					)),
				),
				array (
					'param_name' 	=> 'items_per_column',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Items Per Column', 'wntr-opts'),
					'admin_label'	=> true,
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
						'3'		=> __('Three', 'wntr-opts'),
						'4'		=> __('Fourth', 'wntr-opts'),
			        )),
				),
				array (
					'param_name' 	=> 'number_of_posts',
					'type' 			=> 'textfield',
					'heading' 		=> __('Total Posts', 'wntr-opts'),
					'description' 	=> __('How many total number of items to display per page. (2,3,4 ..)', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'category',
					'type' 	 => 'textfield',
					'heading' 	 => __('Category', 'wntr-opts'),
					'description' 	=> __('Post Category ID', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'height',
					'type' 			=> 'textfield',
					'heading' 		=> __('Height', 'wntr-opts'),
					'description' 	=> __('Blog image height in pixcel (note:enter number without px, ex.50 )( default valiue is : 480 )', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'width',
					'type' 			=> 'textfield',
					'heading' 		=> __('Width', 'wntr-opts'),
					'description' 	=> __('Blog image width in pixcel (note:enter number without px, ex.50 ) ( default valiue is : 600 )', 'wntr-opts'),
					'admin_label'	=> false,
				),
		)
	));		


/**** Hot Product *****/	
		vc_map( array (
				'base' 	 => 'home_products',
				'name' 	 => __('Hot Product', 'wntr-opts'),
				'description' 	=> __('promotional Product with counter', 'wntr-opts'),
				'category' 	 => __('Winter Builder', 'wntr-opts'),
				'icon' 	 => 'wt-vc-icon-woo_pro',
				'params' 	 => array (
				array (
				'param_name' 	=> 'height',
				'type' 	 => 'textfield',
				'heading' 	 => __('Main Image Height', 'wntr-opts'),
				'description' 	=> __('Main Image Height in pixel (note:enter number without px ex.368)', 'wntr-opts'),
				'admin_label'	=> false,
				),
				array (
				'param_name' 	=> 'width',
				'type' 	 => 'textfield',
				'heading' 	 => __('Main Image Width', 'wntr-opts'),
				'description' 	=> __('Main Image Width in pixel (note:enter number without px ex.280)', 'wntr-opts'),
				'admin_label'	=> false,
				),
				array (
				'param_name' 	=> 'number_of_items',
				'type' 	 => 'textfield',
				'heading' 	 => __('Total Product', 'wntr-opts'),
				'description' 	=> __('2,3,4..', 'wntr-opts'),
				'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'excerpt_length',
					'type' 			=> 'textfield',
					'heading' 		=> __('Limtation of Detail', 'wntr-opts'),
					'description' 	=> __('Limtation of Detail. ex.250', 'wntr-opts'),
					'admin_label'	=> false,
				),	
				)
	));


/**** best Product *****/	
		vc_map( array (
				'base' 	 => 'best_products',
				'name' 	 => __('Best Product', 'wntr-opts'),
				'description' 	=> __('promotional best Product', 'wntr-opts'),
				'category' 	 => __('Winter Builder', 'wntr-opts'),
				'icon' 	 => 'wt-vc-icon-woo_pro',
				'params' 	 => array (
				array (
				'param_name' 	=> 'height',
				'type' 	 => 'textfield',
				'heading' 	 => __('Main Image Height', 'wntr-opts'),
				'description' 	=> __('Main Image Height in pixel (note:enter number without px ex.368)', 'wntr-opts'),
				'admin_label'	=> false,
				),
				array (
				'param_name' 	=> 'width',
				'type' 	 => 'textfield',
				'heading' 	 => __('Main Image Width', 'wntr-opts'),
				'description' 	=> __('Main Image Width in pixel (note:enter number without px ex.280)', 'wntr-opts'),
				'admin_label'	=> false,
				),
				array (
				'param_name' 	=> 'number_of_items',
				'type' 	 => 'textfield',
				'heading' 	 => __('Total Product', 'wntr-opts'),
				'description' 	=> __('2,3,4..', 'wntr-opts'),
				'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'excerpt_length',
					'type' 			=> 'textfield',
					'heading' 		=> __('Limtation of Detail', 'wntr-opts'),
					'description' 	=> __('Limtation of Detail. ex.250', 'wntr-opts'),
					'admin_label'	=> false,
				),	
				)
	));


	
/**** Brand in grid or slider*****/		
	vc_map( array (
			'name' 			=> __('Brand Logos', 'wntr-opts'),
			'description' 	=> __('Brand in Slider', 'wntr-opts'),
			'base' 			=> 'wntr_logo',
			"as_parent" => array('only' => 'wntr_logoinner'),
    		"content_element" => true,
    		"show_settings_on_create" => true,
			 "js_view" => 'VcColumnView',
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-brand',
			'params' 		=> array (
				array (
					'param_name' 	=> 'type',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Type', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'slider'		=> __('Slider', 'wntr-opts'),	
						'grid'		=> __('Grid', 'wntr-opts'),	
					)),
				),
				array (
					'param_name' 	=> 'items_per_column',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Items Per Column', 'wntr-opts'),
					'description' 	=> __('Enter number of items to display per column.', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 	 => array_flip(array(
							'1'	 => __('1', 'wntr-opts'),
							'2'	 => __('2', 'wntr-opts'),	
							'3'	 => __('3', 'wntr-opts'),	
							'4'	 => __('4', 'wntr-opts'),	
							'5'	 => __('5', 'wntr-opts'),	
							'6'	 => __('6', 'wntr-opts'),	
							'7'	 => __('7', 'wntr-opts'),	
					)),
				),
				),
	));	
	
	vc_map( array (
			'base' 			=> 'wntr_logoinner',
			'name' 			=> __('Logo Link', 'wntr-opts'),
			"content_element" => true,
		    "as_child" => array('only' => 'wntr_logo'),
			"show_settings_on_create" => true,	
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-multiple-link',
			'params' 		=> array (
				array (
					'param_name' 	=> 'title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'description' 	=> __('Logo Image Title ex.Feature', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'link_url',
					'type' 			=> 'textfield',
					'heading' 		=> __('Link URL', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'target',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Link | Target', 'wntr-opts'),
					'admin_label'	=> false,
					'value'			=> array_flip( array(
						'' 			=> 'Default | _self',
						'_blank' 	=> 'New Tab or Window | _blank' ,
					)),
				),
				array (
					'param_name' 	=> 'image',
					'type' 			=> 'attach_image',
					'description' 	=> __('Attach here Feature Image.', 'wntr-opts'),
					'admin_label'	=> false,
				),
		)
	));
	
// Button
	vc_map( array (
			'base' 			=> 'wntr_button',
			'name' 			=> __('Button', 'wntr-opts'),
			'description' 	=> __('Type of buttons with Icon', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-button',
			'params' 		=> array (
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textfield',
					'heading' 		=> __('Button Name', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'align',
					'type' 			=> 'textfield',
					'heading' 		=> __('Align', 'wntr-opts'),
					'description' 	=> __('Button Alignment ex.left,right,center', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'type',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Button Type', 'wntr-opts'),
					'admin_label'	=> false,
					'description' 	=> __('Defualt valuse is medium', 'wntr-opts'),
					'value' 		=> array_flip(array(
						'medium'	=> __('Medium', 'wntr-opts'),
						'small'		=> __('Small', 'wntr-opts'),
						'big'		=> __('Big', 'wntr-opts'),
						'mini'		=> __('Mini', 'wntr-opts'),
					)),
				),
				array (
					'param_name' 	=> 'icon',
					'type' 			=> 'textfield',
					'heading' 		=> __('Font Awesome Icon', 'wntr-opts'),
					'description' 	=> __('fa-arrows-alt', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'icon_align',
					'type' 			=> 'textfield',
					'heading' 		=> __('Icon Alignment', 'wntr-opts'),
					'description' 	=> __('Icon Alignment ex.left,right,center', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'background_color',
					'type' 			=> 'colorpicker',
					'heading' 		=> __('Icon Background Color', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'link_url',
					'type' 			=> 'textfield',
					'heading' 		=> __('Link URL', 'wntr-opts'),
					'description' 	=> __('ex. https://www.google.co.in/', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'target',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Button | Target', 'wntr-opts'),
					'description' 	=> __('Define where to open the linked document', 'wntr-opts'),
					'admin_label'	=> false,
					'value'			=> array_flip( array(
						'' 			=> 'Default | _self',
						'_blank' 	=> 'New Tab or Window | _blank' ,
					)),
				),
		)
	));
// Category Tabs	
	vc_map( array (
				'base' 	 => 'woo_categories',
				'name' 	 => __('Categories Tabs', 'wntr-opts'),
				'description' 	=> __('Show Category Tab wise products in grid/slider', 'wntr-opts'),
				'category' 	 => __('Winter Builder', 'wntr-opts'),
				'icon' 	 => 'wntr-vc-icon-tabs',
				'params' 	 => array (
							array (
								'param_name' 	=> 'type',
								'type' 	     	=> 'dropdown',
								'heading' 	 	=> __('Type', 'wntr-opts'),
								'admin_label'	=> false,
								'value' 	 	=> array_flip(array(
										'slider' => __('Slider', 'wntr-opts'),	
										'grid'	 => __('Grid', 'wntr-opts'),	
								)),
							),
							array (
								'param_name' 	=> 'items_per_column',
								'type' 	 => 'dropdown',
								'heading' 	 => __('Items Per Column', 'wntr-opts'),
								'description' 	=> __('Enter number of items to display per column.', 'wntr-opts'),
								'admin_label'	=> false,
								'value' 	 => array_flip(array(
								'2'	 => __('2', 'wntr-opts'),	
								'3'	 => __('3', 'wntr-opts'),	
								'4'	 => __('4', 'wntr-opts'),	
								'5'	=> __('5', 'wntr-opts'),
							)),
							),
							array (
								'param_name' 	=> 'items_per_page',
								'type' 	 => 'textfield',
								'heading' 	 => __('Items', 'wntr-opts'),
								'description' 	=> __('Enter number of items to display per column.', 'wntr-opts'),
								'admin_label'	=> false,
							),
							array (
								'param_name' 	=> 'category_ids',
								'type' 	 => 'textfield',
								'heading' 	 => __('Category Id', 'wntr-opts'),
								'description' 	=> __('Enter ID of product category to display products(ex. 88,105,165)', 'wntr-opts'),
								'admin_label'	=> false,
							),
				)
		));	


/**** woo category *****/	
		vc_map( array (
				'base' 	 => 'woo_categories_slider',
				'name' 	 => __('Woo Categories Slider', 'wntr-opts'),
				'description' 	=> __('Show All Categories slider', 'wntr-opts'),
				'category' 	 => __('Winter Builder', 'wntr-opts'),
				'icon' 	 => 'wntr-vc-icon-tabs',
				'params' 	 => array (
			    array (
						'param_name' 	=> 'items_per_column',
						'type' 	 => 'dropdown',
						'heading' 	 => __('Items Per Column', 'wntr-opts'),
						'description' 	=> __('Enter number of items to display per column.', 'wntr-opts'),
						'admin_label'	=> false,
						'value' 	 => array_flip(array(
						'2'	 => __('2', 'wntr-opts'),	
						'3'	 => __('3', 'wntr-opts'),	
						'4'	 => __('4', 'wntr-opts'),	
						'5'	=> __('5', 'wntr-opts'),
						'6'	=> __('6', 'wntr-opts'),
						'7'	=> __('7', 'wntr-opts'),
						'8'	=> __('8', 'wntr-opts'),
							)),
				),		
				array (
					'param_name' 	=> 'display_category',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Category Display', 'wntr-opts'),
					'admin_label'	=> false,
					'description' 	=> __('Default category display.', 'wntr-opts'),
					'value' 		=> array_flip(array(
						'0'		=> __('Parent', 'wntr-opts'),
						''		=> __('ParentCategory + SubCategory', 'wntr-opts'),
					)),
				),
				array (
					'param_name' 	=> 'hide_empty',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Hide Empty Category', 'wntr-opts'),
					'admin_label'	=> false,
					'description' 	=> __('select option for hide/display empty category', 'wntr-opts'),
					'value' 		=> array_flip(array(
						'1'		=> __('Yes', 'wntr-opts'),
						'0'		=> __('No', 'wntr-opts'),
					)),
				),
				array (
					'param_name' 	=> 'height',
					'type' 			=> 'textfield',
					'heading' 		=> __('Category Image Height', 'wntr-opts'),
					'description' 	=> __('Category Image Height in pixcel (note:enter number without px ex.130)', 'wntr-opts'),
					'admin_label'	=> false,
				),
					array (
					'param_name' 	=> 'width',
					'type' 			=> 'textfield',
					'heading' 		=> __('Category Image Width', 'wntr-opts'),
					'description' 	=> __('Category Image Width in pixcel (note:enter number without px ex.130)', 'wntr-opts'),
					'admin_label'	=> false,
				),
				)
		));


/**** CMS Image Banners *****/		
	vc_map( array (
			'base' 			=> 'wntr_cms_block',
			'name' 			=> __('CMS Banners Block', 'wntr-opts'),
			'description' 	=> __('CMS block with background Images', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-cms',
			'params' 		=> array (
			   array (
					'param_name' 	=> 'classname',
					'type' 			=> 'textfield',
					'heading' 		=> __('Classname', 'wntr-opts'),
					'description' 	=> __('Give classname for this block', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'image',
					'type' 			=> 'attach_image',
					'heading' 		=> __('Image', 'wntr-opts'),
					'description' 	=> __('Attach image for cms block from here', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'style',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Style Type', 'wntr-opts'),
					'admin_label'	=> false,
					'description' 	=> __('Select type of Hover effect.', 'wntr-opts'),
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
					)),
				),
				array (
					'param_name' 	=> 'link_text',
					'type' 			=> 'textfield',
					'heading' 		=> __('link_text', 'wntr-opts'),
					'description' 	=> __('URL linkable text  ex.Shop Now', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'link_url',
					'type' 			=> 'textfield',
					'heading' 		=> __('Link URL', 'wntr-opts'),
					'description' 	=> __('ex. https://www.google.co.in/', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'target',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Button | Target', 'wntr-opts'),
					'description' 	=> __('Define where to open the linked document', 'wntr-opts'),
					'admin_label'	=> false,
					'value'			=> array_flip( array(
						'' 			=> 'Default | _self',
						'_blank' 	=> 'New Tab or Window | _blank' ,
					)),
				),
				array (
					'param_name' 	=> 'text1',
					'type' 			=> 'textfield',
					'heading' 		=> __('Text1', 'wntr-opts'),
					'description' 	=> __('Text1  ex. Table Lights', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'text2',
					'type' 			=> 'textfield',
					'heading' 		=> __('Text2', 'wntr-opts'),
					'description' 	=> __('Text2  ex. The World Catelog Ideas', 'wntr-opts'),
					'admin_label'	=> false,
				),
		)
	));		
					
// Contact Address	
	vc_map( array (
			'base' 			=> 'wntr_address',
			'name' 			=> __('Contact Address', 'wntr-opts'),
			'description' 	=> __('Display contact details', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-contact_box',
			'params' 		=> array (
				array (
					'param_name' 	=> 'title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'description' 	=> __('', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'description',
					'type' 			=> 'textfield',
					'heading' 		=> __('Description', 'wntr-opts'),
					'description' 	=> __('', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'address_label',
					'type' 			=> 'textfield',
					'heading' 		=> __('Address Label', 'wntr-opts'),
					'description' 	=> __('', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Address', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'phone_label',
					'type' 			=> 'textfield',
					'heading' 		=> __('Phone Label', 'wntr-opts'),
					'description' 	=> __('', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'phone',
					'type' 			=> 'textfield',
					'heading' 		=> __('Phone Number', 'wntr-opts'),
					'description' 	=> __('', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'email_label',
					'type' 			=> 'textfield',
					'heading' 		=> __('Email Label', 'wntr-opts'),
					'description' 	=> __('', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'email',
					'type' 			=> 'textfield',
					'heading' 		=> __('Email', 'wntr-opts'),
					'description' 	=> __('Give Email Address Here ex. support@Winter.com', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'email_link',
					'type' 			=> 'textfield',
					'heading' 		=> __('Email Link', 'wntr-opts'),
					'description' 	=> __('(ex. mailto:support@Winter.com)', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'other_label',
					'type' 			=> 'textfield',
					'heading' 		=> __('Other Label', 'wntr-opts'),
					'description' 	=> __('', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'other',
					'type' 			=> 'textfield',
					'heading' 		=> __('Other', 'wntr-opts'),
					'description' 	=> __('ex,time of office', 'wntr-opts'),
					'admin_label'	=> true,
				),
		)
	));	
// Counter						
	vc_map( array (
			'base' 			=> 'wntr_counter',
			'name' 			=> __('Counter', 'wntr-opts'),
			'description' 	=> __('Number counter', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-counter',
			'params' 		=> array (
				array (
					'param_name' 	=> 'title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'description' 	=> __('Title for the counter', 'wntr-opts'),
					'admin_label'	=> true,
				),	
				array (
					'param_name' 	=> 'id',
					'type' 			=> 'textfield',
					'heading' 		=> __('Unique Id', 'wntr-opts'),
					'description' 	=> __('Temp1', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'start',
					'type' 			=> 'textfield',
					'heading' 		=> __('Start Number', 'wntr-opts'),
					'description' 	=> __('Start Number for counter', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'end',
					'type' 			=> 'textfield',
					'heading' 		=> __('End Number', 'wntr-opts'),
					'description' 	=> __('End Number for counter', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'decimal',
					'type' 			=> 'textfield',
					'heading' 		=> __('Decimal Number', 'wntr-opts'),
					'description' 	=> __('One or more digits to the right of the decimal point. Default : 0', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'duration',
					'type' 			=> 'textfield',
					'heading' 		=> __('Duration', 'wntr-opts'),
					'description' 	=> __('Duration for the Counter when it ends. Default : 20', 'wntr-opts'),
					'admin_label'	=> true,
				),	
		)
	));
	
// FAQ
	vc_map( array (
			'base' 			=> 'faqs',
			'name' 			=> __('FAQ', 'wntr-opts'),
			'description' 	=> __('List of FAQs questions & answers', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-faq',
			'params' 		=> array (
				array (
					'param_name' 	=> 'style',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Style Type', 'wntr-opts'),
					'admin_label'	=> false,
					'description' 	=> __('Select type of FAQs style.', 'wntr-opts'),
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
					)),
				),
				array (
					'param_name' 	=> 'category',
					'type' 			=> 'textfield',
					'heading' 		=> __('Category ID', 'wntr-opts'),
					'description' 	=> __('Enter Category ID of faq categories ex.30', 'wntr-opts'),
					'admin_label'	=> true,
				),	
		)
	));			
// Feature Content	
	vc_map( array (
			'base' 			=> 'wntr_about',
			'name' 			=> __('Feature Content', 'wntr-opts'),
			'description' 	=> __('Feature image with content', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-feature_box',
			'params' 		=> array (
				array (
					'param_name' 	=> 'title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'description' 	=> __('Title ex.Feature', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'image',
					'type' 			=> 'attach_image',
					'description' 	=> __('Attach here Feature Image.', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'image_align',
					'type' 			=> 'textfield',
					'heading' 		=> __('Image Align', 'wntr-opts'),
					'description' 	=> __('Image Align ex.left,right,center', 'wntr-opts'),
					'admin_label'	=> false,
				),
			    array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'link_text',
					'type' 			=> 'textfield',
					'heading' 		=> __('Link Text', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'link_url',
					'type' 			=> 'textfield',
					'heading' 		=> __('Link URL', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'target',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Button | Target', 'wntr-opts'),
					'description' 	=> __('Define where to open the linked document', 'wntr-opts'),
					'admin_label'	=> false,
					'value'			=> array_flip( array(
						'' 			=> 'Default | _self',
						'_blank' 	=> 'New Tab or Window | _blank' ,
					)),
				),
		)
	));

/**** Home Page Service *****/		
	vc_map( array (
			'base' 			=> 'wntr_service',
			'name' 			=> __('Home Page Service', 'wntr-opts'),
			'description' 	=> __('Style For Services with Images', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-services',
			'params' 		=> array (
				array (
					'param_name' 	=> 'service_number',
					'type' 			=> 'textfield',
					'heading' 		=> __('Service Number', 'wntr-opts'),
					'description' 	=> __('Identify Number for service. ex.1,2,3,..', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'dark_service_title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Dark Service Title', 'wntr-opts'),
					'description' 	=> __('Dark Service Title ex. 24 x 7 free Support', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'service_title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Service Title', 'wntr-opts'),
					'description' 	=> __('Service Title ex. 24 x 7 free Support', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'style',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Type', 'wntr-opts'),
					'admin_label'	=> false,
					'description' 	=> __('Select type of Service style.', 'wntr-opts'),
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
					)),
				),
		)
	));	

// Lists
	vc_map( array (
			'name' 			=> __('Lists', 'wntr-opts'),
			'description' 	=> __('Show list of content with icon', 'wntr-opts'),
			'base' 			=> 'wntr_list',
			"as_parent" => array('only' => 'list_item'),
    		"content_element" => true,
    		"show_settings_on_create" => false,
			 "js_view" => 'VcColumnView',
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-list',
	));	
	vc_map( array (
			'base' 			=> 'list_item',
			'name' 			=> __('List Item', 'wntr-opts'),
			"content_element" => true,
		    "as_child" => array('only' => 'wntr_list'),
			"show_settings_on_create" => true,	
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-portfolio_grid',
			'params' 		=> array (
				array (
					'param_name' 	=> 'icon',
					'type' 			=> 'textfield',
					'heading' 		=> __('Font Awesome Icon', 'wntr-opts'),
					'description' 	=> __('fa-arrows-alt', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'color',
					'type' 			=> 'colorpicker',
					'heading' 		=> __('Icon Color', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'link_url',
					'type' 			=> 'textfield',
					'heading' 		=> __('Link URL', 'wntr-opts'),
					'description' 	=> __('ex. https://www.google.co.in/', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'target',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Button | Target', 'wntr-opts'),
					'description' 	=> __('Define where to open the linked document', 'wntr-opts'),
					'admin_label'	=> false,
					'value'			=> array_flip( array(
						'' 			=> 'Default | _self',
						'_blank' 	=> 'New Tab or Window | _blank' ,
					)),
				),
		)
	));
	
// Links
	vc_map( array (
			'name' 			=> __('Multiple Links', 'wntr-opts'),
			'description' 	=> __('Craete linkable text', 'wntr-opts'),
			'base' 			=> 'wntr_links',
			"as_parent" => array('only' => 'link'),
    		"content_element" => true,
    		"show_settings_on_create" => false,
			 "js_view" => 'VcColumnView',
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-multiple-link',
	));	

	vc_map( array (
			'base' 			=> 'link',
			'name' 			=> __('Link', 'wntr-opts'),
			"content_element" => true,
		    "as_child" => array('only' => 'wntr_links'),
			"show_settings_on_create" => true,	
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-portfolio_grid',
			'params' 		=> array (
				array (
					'param_name' 	=> 'link_url',
					'type' 			=> 'textfield',
					'heading' 		=> __('Link URL', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'target',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Button | Target', 'wntr-opts'),
					'description' 	=> __('Define where to open the linked document', 'wntr-opts'),
					'admin_label'	=> false,
					'value'			=> array_flip( array(
						'' 			=> 'Default | _self',
						'_blank' 	=> 'New Tab or Window | _blank' ,
					)),
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
		)
	));	

// Team	
	vc_map( array (
			'base' 			=> 'wntr_ourteam',
			'name' 			=> __('Our Team', 'wntr-opts'),
			'description' 	=> __('Team members in grid or slider', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-team',
			'params' 		=> array (
				array (
					'param_name' 	=> 'type',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Type', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'grid'		=> __('Grid', 'wntr-opts'),
						'slider'	=> __('Slider', 'wntr-opts'),
					)),
				),
				array (
					'param_name' 	=> 'items_per_column',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Items Per Column', 'wntr-opts'),
					'description' 	=> __('Enter number of items to display per column.', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
						'3'		=> __('Three', 'wntr-opts'),
						'4'		=> __('Four', 'wntr-opts'),
						'5'		=> __('Five', 'wntr-opts'),		
					)),
				),
				array (
					'param_name' 	=> 'number_of_posts',
					'type' 			=> 'textfield',
					'heading' 		=> __('Total Posts', 'wntr-opts'),
					'description' 	=> __('How many total number of items to display. (2,3,4..)', 'wntr-opts'),
					'admin_label'	=> true,
				),
		)
	));	
	
// Product Single or multiple Category List
vc_map( array (
		'base' 			=> 'wntr_single_category',
		'name' 			=> __('Product Category', 'wntr-opts'),
		'description' 	=> __('Show single or multiple category list by ID', 'wntr-opts'),
		'category' 		=> __('Winter Builder', 'wntr-opts'),
		'icon' 			=> 'wntr-vc-icon-list',
		'params' 		=> array (
			array (
					'param_name' 	=> 'text1',
					'type' 			=> 'textfield',
					'heading' 		=> __('Text1', 'wntr-opts'),
					'description' 	=> __('Text1  ex. Table Lights', 'wntr-opts'),
					'admin_label'	=> false,
				),
			array (
				'param_name' 	=> 'category_name',
				'type' 			=> 'textfield',
				'heading' 		=> __('Category Ids', 'wntr-opts'),
				'description' 	=> __('Add multiple product category ids (ex. 20, 25 ,33.. etc.)' , 'wntr-opts'),
				'admin_label'	=> true,
				'value'			=> array_flip( wntr_get_categories( 'product_cat' ) ),
			),
			array (
					'param_name' 	=> 'link_text',
					'type' 			=> 'textfield',
					'heading' 		=> __('link_text', 'wntr-opts'),
					'description' 	=> __('URL linkable text  ex.Shop Now', 'wntr-opts'),
					'admin_label'	=> false,
				),
			array (
				'param_name' 	=> 'link_url',
				'type' 			=> 'textfield',
				'heading' 		=> __('Link URL', 'wntr-opts'),
				'description' 	=> __('ex. https://www.google.co.in/', 'wntr-opts'),
			),
	)
));	

// Pricing Table
	vc_map( array (
			'base' 			=> 'wntr_pricingtable',
			'name' 			=> __('Pricing Table', 'wntr-opts'),
			'description' 	=> __('responsive pricing table content', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-pricing_item',
			'params' 		=> array (	
				array (
					'param_name' 	=> 'heading',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'description' 	=> __('', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'selected',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Featured', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'no'		=> __('No', 'wntr-opts'),
						'yes'		=> __('Yes', 'wntr-opts')
					)),
				),
				array (
					'param_name' 	=> 'button_text',
					'type' 			=> 'textfield',
					'heading' 		=> __('Button Text', 'wntr-opts'),
					'description' 	=> __('Read More', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'button_link',
					'type' 			=> 'textfield',
					'heading' 		=> __('Button Link', 'wntr-opts'),
					'description' 	=> __('Link will appear only if this field will be filled.', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'target',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Button | Target', 'wntr-opts'),
					'description' 	=> __('Define where to open the linked document', 'wntr-opts'),
					'admin_label'	=> false,
					'value'			=> array_flip( array(
						'' 			=> 'Default | _self',
						'_blank' 	=> 'New Tab or Window | _blank' ,
					)),
				),
				array (
					'param_name' 	=> 'price',
					'type' 			=> 'textfield',
					'heading' 		=> __('Price', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'price_per',
					'type' 			=> 'textfield',
					'heading' 		=> __('Price for period', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
					'value'			=> '<ul><li><strong>List</strong> item</li></ul>',
				),
			)
	));	
// Products 	
	vc_map( array (
			'base' 			=> 'woo_products',
			'name' 			=> __('Products', 'wntr-opts'),
			'description'   => __('Show products in grid or slider', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-woo_pro',
			'params' 		=> array (
				array (
					'param_name' 	=> 'type',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Type', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'slider'	=> __('Slider', 'wntr-opts'),	
						'grid'		=> __('Grid', 'wntr-opts'),	
					)),
				),
				array (
					'param_name' 	=> 'items_per_column',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Items Per Column  ( use if product type is "slider") ', 'wntr-opts'),
					'description' 	=> __('Enter number of items to display per column.', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
						'3'		=> __('Three', 'wntr-opts'),
						'4'		=> __('Four', 'wntr-opts'),
						'5'		=> __('Five', 'wntr-opts'),
						'6'		=> __('Six', 'wntr-opts'),		
									
					)),
				),
				array (
					'param_name' 	=> 'classname',
					'type' 			=> 'textfield',
					'heading' 		=> __('classname', 'wntr-opts'),
					'description' 	=> __('classname', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content ( when Type is "Grid" add columns value to set items per column) ', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed like [recent_products per_page="12" columns="4" orderby="date" order="desc"]  for new product', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'no_more',
					'type' 			=> 'textfield',
					'heading' 		=> __('No more Products ( use if Product type is "grid")', 'wntr-opts'),
					'description' 	=> __('no more product description', 'wntr-opts'),
					'admin_label'	=> true,
				),
		)
	));


	//vertical  Products 	
	vc_map( array (
			'base' 			=> 'woo_products_var',
			'name' 			=> __('Products Two Row', 'wntr-opts'),
			'description'   => __('Show products vartical in grid or slider', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-woo_pro',
			'params' 		=> array (
				array (
					'param_name' 	=> 'type',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Type', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'slider'	=> __('Slider', 'wntr-opts'),	
						'grid'		=> __('Grid', 'wntr-opts'),	
					)),
				),
				array (
					'param_name' 	=> 'items_per_column',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Items Per Column  ( use if product type is "slider") ', 'wntr-opts'),
					'description' 	=> __('Enter number of items to display per column.', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
						'3'		=> __('Three', 'wntr-opts'),
						'4'		=> __('Four', 'wntr-opts'),
						'5'		=> __('Five', 'wntr-opts'),	
									
					)),
				),
				array (
					'param_name' 	=> 'classname',
					'type' 			=> 'textfield',
					'heading' 		=> __('classname', 'wntr-opts'),
					'description' 	=> __('classname', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content ( when Type is "Grid" add columns value to set items per column) ', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed like [recent_products per_page="12" columns="4" orderby="date" order="desc"]  for new product', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'no_more',
					'type' 			=> 'textfield',
					'heading' 		=> __('No more Products ( use if Product type is "grid")', 'wntr-opts'),
					'description' 	=> __('no more product description', 'wntr-opts'),
					'admin_label'	=> true,
				),
		)
	));

// Products Tabs	
	vc_map( array (
			'name' 			=> __('Product Tabs', 'wntr-opts'),
			'description' 	=> __('Woo products tabs', 'wntr-opts'),
			'base' 			=> 'wntr_product_tabs',
			"as_parent" => array('only' => 'wntr_tab_home'),
    		"content_element" => true,
    		"show_settings_on_create" => true,
			 "js_view" => 'VcColumnView',
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-tabs',
			'params' 		=> array (
				array (
					'param_name' 	=> 'tab1_text',
					'type' 			=> 'textfield',
					'heading' 		=> __('Tab1 Title', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'tab2_text',
					'type' 			=> 'textfield',
					'heading' 		=> __('Tab2 Title', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'tab3_text',
					'type' 			=> 'textfield',
					'heading' 		=> __('Tab3 Title', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'tab4_text',
					'type' 			=> 'textfield',
					'heading' 		=> __('Tab4 Title', 'wntr-opts'),
				),
		)
	));	
	vc_map( array (
			'base' 			=> 'wntr_tab_home',
			'name' 			=> __('Product Tab Container', 'wntr-opts'),
			"content_element" => true,
		    "as_child" => array('only' => 'wntr_product_tabs'),
			"show_settings_on_create" => true,	
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-woo_pro',
			'params' 		=> array (
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
		)
	));
// Services	
	vc_map( array (
			'base' 			=> 'service',
			'name' 			=> __('Service', 'wntr-opts'),
			'description' 	=> __('Service with different icon & styles', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-services',
			'params' 		=> array (
				array (
					'param_name' 	=> 'title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'description' 	=> __('Service Title', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'style',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Type', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
						'3'		=> __('Three', 'wntr-opts'),
						'4'		=> __('Four', 'wntr-opts'),
					)),
				),
				array (
					'param_name' 	=> 'icon',
					'type' 			=> 'textfield',
					'heading' 		=> __('Font Awesome Icon', 'wntr-opts'),
					'description' 	=> __('ex. fa-arrows-alt', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'color',
					'type' 			=> 'colorpicker',
					'heading' 		=> __('Icon Color', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'icon_background_color',
					'type' 			=> 'colorpicker',
					'heading' 		=> __('Icon Background Color', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'link_text',
					'type' 			=> 'textfield',
					'heading' 		=> __('Link Text', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'link_url',
					'type' 			=> 'textfield',
					'heading' 		=> __('Link URL', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'target',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Button | Target', 'wntr-opts'),
					'description' 	=> __('Define where to open the linked document', 'wntr-opts'),
					'admin_label'	=> false,
					'value'			=> array_flip( array(
						'' 			=> 'Default | _self',
						'_blank' 	=> 'New Tab or Window | _blank' ,
					)),
				),
		)
	));	
// Static Text	
	vc_map( array (
			'base' 			=> 'text',
			'name' 			=> __('Static Text', 'wntr-opts'),
			'description' 	=> __('Arbitary text with HTML', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-static-text',
			'params' 		=> array (
				array (
					'param_name' 	=> 'align',
					'type' 			=> 'textfield',
					'heading' 		=> __('Text Align', 'wntr-opts'),
					'description' 	=> __('Text-Alignment ex.left,right,center', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Text Detail', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
		)
	));	

// Tabs ( Horizontal + Vertical )	
	vc_map( array (
			'name' 			=> __('Tabs', 'wntr-opts'),
			'description' 	=> __('Horizontal and Vertical tabs with diiferent styles ', 'wntr-opts'),
			'base' 			=> 'wntr_tabs',
			"as_parent" => array('only' => 'wntr_tab'),
    		"content_element" => true,
    		"show_settings_on_create" => true,
			 "js_view" => 'VcColumnView',
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-tabs',
			'params' 		=> array (
				array (
					'param_name' 	=> 'style',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Style Type', 'wntr-opts'),
					'admin_label'	=> false,
					'description' 	=> __('Select type of Tabs style.', 'wntr-opts'),
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
						'3'		=> __('Three', 'wntr-opts'),
					)),
				),
				array (
					'param_name' 	=> 'tab_type',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Tab Type', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'horizontal'		=> __('Horizontal', 'wntr-opts'),
						'vertical'		=> __('Vertical', 'wntr-opts'),
					)),
				),
		)
	));	
	vc_map( array (
			'base' 			=> 'wntr_tab',
			'name' 			=> __('Tab', 'wntr-opts'),
			"content_element" => true,
		    "as_child" => array('only' => 'wntr_tabs'),
			"show_settings_on_create" => true,	
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-tabs',
			'params' 		=> array (
				array (
					'param_name' 	=> 'title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'description' 	=> __('Title ex.Welcome To Store', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
		)
	));	
// Title
	vc_map( array (
			'base' 			=> 'title',
			'name' 			=> __('Title', 'wntr-opts'),
			'description' 	=> __('Identify name of content or block', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-fancy_heading',
			'params' 		=> array (
				array (
					'param_name' 	=> 'title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'size',
					'type' 			=> 'textfield',
					'heading' 		=> __('Text Size', 'wntr-opts'),
					'description' 	=> __('ex. small,normal,big (default value is normal )', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'align',
					'type' 			=> 'textfield',
					'heading' 		=> __('Text Align', 'wntr-opts'),
					'description' 	=> __('ex.left,right,center  (default value is center )', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'color',
					'type' 			=> 'colorpicker',
					'heading' 		=> __('Text Color', 'wntr-opts'),
				),
				array (
					'param_name' 	=> 'subtitle',
					'type' 			=> 'textfield',
					'heading' 		=> __('Subtitle', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'classname',
					'type' 			=> 'textfield',
					'heading' 		=> __('Classname', 'wntr-opts'),
					'description' 	=> __('extra classname', 'wntr-opts'),
					'admin_label'	=> false,
				),				
		)
	));	
// Testimonials	
	vc_map( array (
			'base' 			=> 'wntr_testimonials',
			'name' 			=> __('Testimonials', 'wntr-opts'),
			'description' 	=> __('Testimonials in grid or slider', 'wntr-opts'),
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-testimonials',
			'params' 		=> array (
				array (
					'param_name' 	=> 'items_per_column',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Items Per Column', 'wntr-opts'),
					'description' 	=> __('Enter number of items to display per column.', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
						'3'		=> __('Three', 'wntr-opts'),
				)),
				),
				array (
					'param_name' 	=> 'number_of_posts',
					'type' 			=> 'textfield',
					'heading' 		=> __('Total Testimonials', 'wntr-opts'),
					'description' 	=> __('How many total number of items to display. (1,2,3,4..)', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'image_width',
					'type' 			=> 'textfield',
					'heading' 		=> __('Image width', 'wntr-opts'),
					'description' 	=> __('Testimonial image width in px, default value is 82px', 'wntr-opts'),
					'admin_label'	=> true,
				),
				array (
					'param_name' 	=> 'image_height',
					'type' 			=> 'textfield',
					'heading' 		=> __('Image Height', 'wntr-opts'),
					'description' 	=> __('Testimonial image height in px, default value is 82px', 'wntr-opts'),
					'admin_label'	=> true,
				),
		)
	));	
// Toggle	
	vc_map( array (
			'name' 			=> __('Toggle', 'wntr-opts'),
			'base' 			=> 'wntr_toggle',
			"as_parent" => array('only' => 'toggle'),
    		"content_element" => true,
			'description' 	=> __('Toggle element block', 'wntr-opts'),
    		"show_settings_on_create" => true,
			 "js_view" => 'VcColumnView',
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-toggle',
			'params' 		=> array (
				array (
					'param_name' 	=> 'style',
					'type' 			=> 'dropdown',
					'heading' 		=> __('Style', 'wntr-opts'),
					'admin_label'	=> false,
					'value' 		=> array_flip(array(
						'1'		=> __('One', 'wntr-opts'),
						'2'		=> __('Two', 'wntr-opts'),
						'3'		=> __('Three', 'wntr-opts'),
						'4'		=> __('Four', 'wntr-opts'),
					)),
				),
		)
	));	
	vc_map( array (
			'base' 			=> 'toggle',
			'name' 			=> __('Toggle Content', 'wntr-opts'),
			"content_element" => true,
		    "as_child" => array('only' => 'wntr_toggle'),
			"show_settings_on_create" => true,	
			'category' 		=> __('Winter Builder', 'wntr-opts'),
			'icon' 			=> 'wntr-vc-icon-toggle',
			'params' 		=> array (
				array (
					'param_name' 	=> 'title',
					'type' 			=> 'textfield',
					'heading' 		=> __('Title', 'wntr-opts'),
					'description' 	=> __('Title ex.Welcome To Store', 'wntr-opts'),
					'admin_label'	=> false,
				),
				array (
					'param_name' 	=> 'content',
					'type' 			=> 'textarea',
					'heading' 		=> __('Content', 'wntr-opts'),
					'description' 	=> __('HTML tags allowed', 'wntr-opts'),
					'admin_label'	=> false,
				),
		)
	));

?>