<?php defined('ABSPATH') or die("No script kiddies please!"); ?>
<div class="right_sidebar">
			<div class="wpmm-upgrade-banner">
              <img src="<?php echo APMM_IMG_DIR;?>/banner-image-pro.png" alt="upgrade-banner-top">
              <div class="wpmm-button-wrap-backend">
                <a href="http://demo.accesspressthemes.com/wordpress-plugins/wp-mega-menu-pro/" class="wpmm-demo-btn" target="_blank"><?php _e('Demo', APMM_TD); ?></a>
                <a href="https://accesspressthemes.com/wordpress-plugins/wp-mega-menu-pro/" target="_blank" class="wpmm-upgrade-btn"><?php _e('Upgrade', APMM_TD); ?></a>
                <a href="https://accesspressthemes.com/wordpress-plugins/wp-mega-menu-pro/" target="_blank" class="wpmm-upgrade-btn"><?php _e('Plugin Information', APMM_TD); ?></a>
              </div>
            <img src="<?php echo APMM_IMG_DIR;?>/banner-feature-pro.png" alt="upgrade-banner-bottom">
        </div>

</div>